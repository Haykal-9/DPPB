/// Model untuk Komentar
class Comment {
  final String user;
  final String initial;
  final double rating;
  final String comment;
  final String time;

  const Comment(this.user, this.initial, this.rating, this.comment, this.time);
}
