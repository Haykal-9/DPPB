// Barrel file: re-export modular widgets for easier maintenance

export 'navigation/nav_bar_item.dart';
export 'product/product_card.dart';
export 'product/menu_product_card.dart';
export 'misc/placeholder_screen.dart';
