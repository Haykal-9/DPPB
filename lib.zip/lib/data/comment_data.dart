import '../models/comment.dart';

/// Product Comments
final List<Comment> mockCommentsList = [
  const Comment(
    'Alex Johnson',
    'A',
    5.0,
    'Absolutely loved the spicy ramen! The broth was rich and flavorful, and the noodles had a perfect chew. Highly recommend for anyone who enjoys a good kick!',
    '2 hours ago',
  ),
  const Comment(
    'Sarah M.',
    'S',
    4.5,
    'The truffle pasta was divine! Every bite was heavenly. A bit pricey but totally worth it for a special occasion. Great ambiance too.',
    'Yesterday',
  ),
  const Comment(
    'Emily Chen',
    'E',
    4.0,
    'Tried the new vegan burger. It was surprisingly juicy and packed with flavor. A fantastic option for non-meat eaters!',
    '2 days ago',
  ),
  const Comment(
    'David Lee',
    'D',
    5.0,
    'Great service and delicious appetizers. The calamari was perfectly crispy. Will definitely be coming back!',
    '3 days ago',
  ),
  const Comment(
    'Jessica W.',
    'J',
    4.5,
    'The chocolate lava cake was simply amazing. Rich, gooey, and the perfect end to our meal.',
    '1 week ago',
  ),
];
